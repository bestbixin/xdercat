<?php
/**
 * 配置命名空间对应的日志文件
 * 默认日志文件为common.log
 * User: bibom
 * Date: 9/7/17
 * Time: 9:24 AM
 */

return [
    "App\\Console\\Commands" => "console-command",
    "AdminLog" => "admin-log",
    "Exception" => "common-error",
    "SQL" => "sql",
];