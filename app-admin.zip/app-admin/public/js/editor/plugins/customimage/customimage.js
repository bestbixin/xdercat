/*******************************************************************************
* KindEditor - WYSIWYG HTML Editor for Internet
* Copyright (C) 2006-2011 kindsoft.net
*
* @author Roddy <lubixin@xiaoyouzi.com>
* @site http://www.kindsoft.net/
* @licence http://www.kindsoft.net/license.php
*******************************************************************************/

KindEditor.plugin('customimage', function(K) {
  var self = this, name = 'customimage';
	self.plugin.customimage = {
		edit : function() {
      if(typeof(self.customImageFunc) == 'function') {
        self.customImageFunc();
      }
    }
  }
	self.clickToolbar(name, self.plugin.customimage.edit);
});
