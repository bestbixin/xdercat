/**
 * common.js
 */
var globalData = [];
function setGData(arr) {
    var key;
    for(key in arr) {
        globalData[key] = arr[key];
    }
}

function getGData(key) {
    if(globalData[key] === undefined) {
        return null;
    }
    return globalData[key];
}

function deleteGData(key) {
    if(globalData[key] !== undefined) {
        delete globalData[key];
    }
}

function pushToCache(key, obj) {
  if(key == '' || key == undefined) {
    return false;
  }
  if(typeof(obj) === 'object') {
    var obj_json = JSON.stringify(obj);
    localStorage.setItem(key, obj_json);
  }
  return false;
}

function getFromCache(key) {
  if(key == '' || key == undefined) {
    return null;
  }
  var result = localStorage.getItem(key);
  if(result != '' && result != undefined) {
    var data = $.parseJSON(result);
    return data;
  }
  return null;
}

function deleteCache(key) {
  if(key == '' || key == undefined) {
    return false;
  }
  localStorage.removeItem(key);
  return true;
}

/*
 * 简单的ajax请求
 * */
function ajax(type, url, data, successCallback, isUseCache, isCloseLoading) {
  if(isCloseLoading == undefined || isCloseLoading == false) {
    var load_index = layer.load(2);
  }
  function _success(result) {
    if(isUseCache === true) {
      var index = _getCacheIndex(url, data);
      var g_data = [];
      g_data[index] = result;
      setGData(g_data);
    }
    if (typeof successCallback == 'function') {
      successCallback(result);
    } else {
      if (result.code == 'N00000') {
        layer.alert(result.message, {title : 0, closeBtn: 0,icon: 1});
      } else {
        layer.alert(result.message, {title : 0, closeBtn: 0, shadeClose: 1,icon: 5});
      }
    }
  }
  function _comlete() {
    if(isCloseLoading == undefined || isCloseLoading == false) {
      layer.close(load_index);
    }
  }
  if(isUseCache === true) {
    var index = _getCacheIndex(url, data);
    var data_cache = getGData(index);
    if(data_cache !== null) {
      _success(data_cache);
      _comlete();
      return;
    }
  }
  $.ajax({
    type: type,
    url: url,
    data: data,
    dataType: "json",
    success: _success,
    complete: _comlete,
    error: function(){
      layer.msg('访问服务失败，请稍后再尝试！');
    }
  });
}
function _getCacheIndex(url, data) {
  var index = '';
  var str_data = '';
  if(data) {
    var key;
    for(key in data) {
      str_data += '&' + key + '=' + data[key];
    }
  }
  index = md5(url + str_data);
  return index;
}

/*
 * 简单的tip
 * */
function tip(msg) {
  layer.alert(msg, {title : 0, closeBtn: 0, shadeClose: 1});
}

function successMsg(msg) {
    layer.alert(msg, {title : 0, closeBtn: 0, shadeClose: 1,icon: 1});
}

function errorMsg(msg) {
    layer.alert(msg, {title : 0, closeBtn: 0, shadeClose: 1,icon: 5});
}

/*
 * 简单的msg
 * */
function msg(message) {
  layer.msg(message);
}

function empty(obj, isSetTimeout) {
    isSetTimeout = isSetTimeout == undefined ? true : false;
    function exe(obj) {
        var $this = $(obj);
        var val = '';
        var prefix = '请填写';
        switch($this.prop("tagName")) {
            case 'INPUT':
                val = $this.val();
                break;
            case 'SELECT':
                val = $this.find('option:selected').val();
                prefix = '请选择';
                break;
            case 'TEXTAREA':
                val = $this.val();
                break;
            default:
                break;
        }
        var tip_index = $this.attr('tip-index');
        layer.close(tip_index);
        if(val == '' || val == undefined) {
            var placeholder = $this.attr('placeholder');
            placeholder = placeholder == undefined ? (prefix + '该信息') : (prefix + placeholder);
            tips(obj, placeholder);
            return true;
        }
        return false;
    }
    if(isSetTimeout) {
        setTimeout(function(){
            return exe(obj);
        }, 300);
    } else {
        return exe(obj);
    }
}

function tips(obj, msg, time) {
    time = time == undefined || time == '' ? 0 : parseInt(time);
    var $this = $(obj);
    var direction = $this.attr('direction');
    direction = direction == undefined ? 2 : direction;
    tip_index = layer.tips(msg, obj, {tips:[direction, '#fd7390'], time: time, shift:-1, tipsMore: true});
    $this.attr('tip-index', tip_index);
}

function to_intval(obj, opt) {
    var val = $(obj).val();
    if (val === '') {
        return 0;
    }
    var v = parseInt(val);
    if (isNaN(v)) {
        if(opt == 'to_null') {
            v = '';
        }else{
            v = 0;
        }
    }
    $(obj).val(v);
    return v;
}

function to_floatval(obj){
    var test1 = /^[1-9]?[0-9]*$/
    var test2 = /^[1-9]?[0-9]*[.]{1}$/
    var test3 = /^[1-9]?[0-9]*[.]{1}[0-9]{1,2}$/
    var value = obj.value
    if(test3.test(value) || test1.test(value) || test3.test(value)){
        value = value
    }
    if(isNaN(value)){
        value = ''
    }
    obj.value = value
    return value
}
function toDecimal2(x) {    
    var f = parseFloat(x);    
    if (isNaN(f)) {    
        return '';    
    }    
    var f = Math.round(x*100)/100;    
    var s = f.toString();    
    if(s == 'NaN'){
        return '';    
    }
    var rs = s.indexOf('.');    
    if (rs < 0) {    
       rs = s.length;    
       s += '.';    
    }    
    while (s.length <= rs + 2) {    
        s += '0';    
    }    
    return s;    
}
function stopPropagation() {
    var e = event ? event : window;
    e.stopPropagation();
}
function pd(txt) {
    console.log(txt);
}
function bindEventForEnter(event, enable_loading) {
    document.onkeydown = function(e){
        var ev = document.all ? window.event : e;
        if (typeof(event) != 'function') {
            return false;
        }
        if(ev.keyCode == 13) {
            if (enable_loading !== undefined && enable_loading === true) {
                var times = $('.layui-layer-shade').attr('times');
                if (times !== undefined) {
                    return false;
                }
            }
            event();
            return false;
        }
    }
}
function removeEvent(obj) {
    var _html = $(obj).html();
    if (_html == undefined) {
        return ;
    }
    $(obj).html(_html);
}
