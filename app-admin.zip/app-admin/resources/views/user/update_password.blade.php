@include('common.head')
<link rel="stylesheet" href="<?php echo vasset('/css/login.css'); ?>" />
<div class="banner">
    <div class="banner-logo"><img src="<?php echo vasset('/img/logo.png'); ?>"></div>
</div>
<form id="form" method="post">
    <ul class="box">
        <li>修改密码</li>
        <li><input id="password" name="password" class="form-control" placeholder="新密码" type="password" value="" /></li>
        <li style="margin-bottom:10px;"><input id="check_password" name="check_password" class="form-control" placeholder="请再输入一次新密码" type="password" /></li>
        <li><input type="button" value="修改密码" onclick="save()" class="btn-login"></li>
    </ul>
</form>
<script type="text/javascript">
function save() {
    var password = $('#password').val();
    if(password == '') {
        tip('请输入新密码');
        return;
    }
    var check_password = $('#check_password').val();
    if(password == '') {
        tip('请输入确认密码');
        return;
    }
    if (check_password != password) {
        tip('两次输入密码不一致');
        return;
    }
    password = md5(password);
    var data = {password:password};
    function successStore(result) {
        if (result.status) {
            msg(result.msg);
            window.location.href = "<?php echo requestUrl('/') ?>";
        } else {
            msg(result.msg);
        }
    }
    ajax("post", "<?php echo requestUrl('/sso/updatePassword') ?>", data, successStore);
}
</script>
@include('common.bottom')
