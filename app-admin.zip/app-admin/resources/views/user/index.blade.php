@include('common.head')
<link rel="stylesheet" href="<?php echo vasset('/css/login.css'); ?>" />
<div class="banner">
    <div class="banner-logo"><img src="<?php echo vasset('/img/logo.png'); ?>"></div>
</div>
<form id="form" method="post">
    <ul class="box">
        <li>后台管理系统</li>
        <li><input id="user_name" name="user_name" class="form-control" placeholder="用户名" type="text" value="" /></li>
        <li style="margin-bottom:10px;"><input id="password" name="password" class="form-control" placeholder="密码" type="password" /></li>
        <li><input type="button" value="登录" onclick="login()" class="btn-login"></li>
    </ul>
</form>
<script type="text/javascript">
    $(function () {
        bindEventForEnter(login, true);
    });
    function login() {
        var user_name = $('#user_name').val();
        if(user_name == '') {
            tip('请输入用户名');
            return;
        }
        var password = $('#password').val();
        if(password == '') {
            tip('请输入密码');
            return;
        }
        password = md5(password);
        var data = {user_name:user_name,password:password};
        function successStore(result) {
            if (result.status) {
                msg(result.msg);
                setTimeout(function() {
                    window.location.href = "<?php echo requestUrl('/'); ?>";
                }, 1000);
            } else {
                msg(result.msg);
            }
        }
        ajax("post", "<?php echo requestUrl('/sso/login') ?>", data, successStore);
    }
</script>
@include('common.bottom')
