<html>
<head>
</head>
<body style="padding-top:40px; padding-bottom:40px; width:99%; text-align:center; font:700 16px/1.5em Arial,Verdana,'microsoft yahei';">
<div style="margin-right:auto; margin-left:auto; width:300px; height:200px; background:#f2dede; text-align:center; border:1px solid #ebccd1;">
    <h5 style="color:#A94402; font-weight:normal;">失败消息</h5>
    <h2 style="color:#a94442; padding:5px 16px; line-height:35px;"><?php echo e($message); ?></h2>
    <div style=" font-size:10px;">
        <span id="time"><?php echo e($time); ?></span>秒钟后跳转...
    </div>
</div>
<script type="text/javascript">

    delayURL();
    function delayURL()
    {
        var delay 	= document.getElementById("time").innerHTML;
        var t 		= setTimeout("delayURL()", 1000);

        if(delay > 0)
        {
            delay--;
            document.getElementById("time").innerHTML = delay;
        }
        else
        {
            clearTimeout(t);
            history.go(-1);
        }
    }
</script>
</body>
</html>

