<?php $app_menu = config('app_menu'); ?>
<div class="navbar navbar-inverse navbar-fixed-top" style="z-index:103000000">
    <div class="navbar-inner">
        <div class="container-fluid row-fluid">
            <a class="brand left-span" href="#">
                爱客章系统后台
            </a>
            <div class="nav-collapse collapse">
                <ul class="nav">
                    <?php foreach ($app_menu as $first_menu): ?>
                    <li <?php if ($first_menu['is_active'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo requestUrl('/' . $first_menu['code']); ?>"><?php echo $first_menu['name']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
                <ul class="nav pull-right">
                    <li><a href="#"><?php echo \App\Http\Services\UserService::getUser()['admin_name']; ?></a></li>
                    <li role="presentation" class="dropdown">
                        <a aria-expanded="false" class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <span class="icon-white icon-user"></span> 系统操作 <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="<?php echo requestUrl('/sso/updatePassword'); ?>"><span class="icon-repeat"></span> 修改密码</a></li>
                            <li><a href="<?php echo requestUrl('/sso/logout'); ?>"><span class="icon-arrow-right"></span> 退出登录</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="left-container left-span" style="overflow-y: auto;height: 92%;">
            <div class="sidebar-nav">
                <ul class="nav nav-list">
                    <?php foreach ($app_menu as $first_menu): ?>
                        <?php if ($first_menu['is_active'] == 1 && !empty($first_menu['sub_menu'])): ?>
                            <?php foreach ($first_menu['sub_menu'] as $sub_menu): ?>
                            <li <?php if ($sub_menu['is_active'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo requestUrl('/' . $first_menu['code'] . '/' . $sub_menu['code']); ?>"><?php echo $sub_menu['name'];?></a></li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="right-container rigth-span" style="margin-left: 12%;min-width: 980px">
