<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="format-detection" content="telephone=no, email=no" />
        <title>后台管理系统</title>
        <link rel="shortcut icon" href="http://img.seeyouyima.com/shenmiao/images/favicon.ico" />
        <link rel="stylesheet" href="<?php echo vasset('/css/bootstrap.min.css'); ?>" />
        <link rel="stylesheet" href="<?php echo vasset('/css/common.css'); ?>" />
        <script type="text/javascript" src="<?php echo vasset('/js/jquery-1.11.1.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo vasset('/js/layer/layer.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo vasset('/js/bootstrap.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo vasset('/js/md5.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo vasset('/js/common.js'); ?>"></script>
    </head>
    <body>
