<?php
namespace App\Console\Commands;


use App\Utils\Log\LoggerConfig;
use App\Utils\Log\LoggerFactory;
use Illuminate\Console\Command;

class BaseCommand extends Command
{
    protected $log;

    public function __construct($class_name)
    {
        parent::__construct();
        $this->configLog();
        $this->log = LoggerFactory::getLogger($class_name);
    }

    private function configLog()
    {
        LoggerConfig::setLogDir(env("LOG_DIR", "/tmp"));
        LoggerConfig::setNameMap(config("logger"));
        LoggerConfig::registerShutdown();
    }

    protected function logger($msg) {
        $this->info('[' . date('Y-m-d H:i:s') . '] ' . $msg);// 显示到显示器
        $this->log->info($msg);// 记录日志
    }
}