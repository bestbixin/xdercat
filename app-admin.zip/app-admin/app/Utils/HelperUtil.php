<?php
/**
 *
 * put your common helper functions in here
 *
 */


if ( ! function_exists('vasset'))
{
    function vasset($url)
    {
        $version = config("app.version");
        if (!(strpos($url, 'http://') !== false || strpos($url, 'https://') !== false)) {
            $url = config("app.url") . $url;
        }
        return strpos($url, '?') === false ? $url . "?v=" . $version : $url . "&v=" . $version;
    }
}

if ( ! function_exists('requestUrl'))
{
    function requestUrl($url)
    {
        if (strpos($url, 'http://') !== false || strpos($url, 'https://') !== false) {
            return $url;
        }
        return config("app.url") . $url;
    }
}

if ( ! function_exists('p'))
{
    function p($t) {
        echo '<pre>';
        print_r($t);
        echo '</pre>';
    }
}

if ( ! function_exists('pd'))
{
    function pd($t) {
        p($t);
        die;
    }
}

if ( ! function_exists('filterData'))
{
    function filterData(&$data, $filterFormat) {
        if (!is_array($data)) {
            throw new \Exception("filter data is not array");
        }
        if (!is_array($filterFormat)) {
            throw new \Exception("filter format is not array");
        }
        $result = "";
        foreach ($filterFormat as $column => $format) {
            if (!is_array($format)) {
                continue;
            }
            if (!isset($data[$column])) {
                $data[$column] = isset($format['default']) ? $format['default'] : null;
            }
            foreach ($format as $verify_method => $error_msg) {
                if (!empty($result)) {
                    continue;
                }
                switch ($verify_method) {
                    case "empty":
                        $result = empty($data[$column]) ? $error_msg : "";
                        break;
                    case "numeric":
                        $result = !is_numeric($data[$column]) ? $error_msg : "";
                        break;
                    case "array":
                        $result = !is_array($data[$column]) ? $error_msg : "";
                        break;
                    case "md5empty":
                        $result = empty($data[$column]) || md5("") == $data[$column] ? $error_msg : "";
                        break;
                    default:
                        break;
                }
            }
            if (isset($format['type'])) {
                switch ($format['type']) {
                    case "integer":
                        $data[$column] = intval($data[$column]);
                        break;
                    case "string":
                        $data[$column] = strval($data[$column]);
                        break;
                    case "float":
                        $data[$column] = floatval($data[$column]);
                        break;
                    case "array":
                        $data[$column] = is_array($data[$column]) ? $data[$column] : [];
                        break;
                    case "bool":
                        $data[$column] = $data[$column] ? true : false;
                        break;
                    case "object":
                        $data[$column] = is_object($data[$column]) ? $data[$column] : new \stdClass();
                        break;
                    default:
                        break;
                }
            }
        }
        return $result;
    }
}


if ( ! function_exists('checkedStr'))
{
    function checkedStr($checked_value, $check_value) {
        if ($checked_value == $check_value) {
            return ' checked="checked" ';
        }
        return '';
    }
}

if ( ! function_exists('readOnlyStr'))
{
    function readOnlyStr($editable) {
        if (!$editable) {
            return ' readonly="readonly" ';
        }
        return '';
    }
}

if ( ! function_exists('disabled'))
{
    function disabled($editable) {
        if (!$editable) {
            return ' disabled ';
        }
        return '';
    }
}


if ( ! function_exists('successJson'))
{
    function successJson(array $data = [], $msg = "success", $code = 200)
    {
        responseJson($data, $msg, $code, true);
    }
}

if ( ! function_exists('errorJson'))
{
    function errorJson($msg = "error", $code = 300, array $data = [])
    {
        responseJson($data, $msg, $code, false);
    }
}

if ( ! function_exists('responseJson'))
{
    /**
     *
     * code:200 success
     * code:300 data error
     * code:400 service error
     *
     * @param array $data
     * @param string $msg
     * @param int $code
     * @param bool $status
     */
    function responseJson(array $data = [], $msg = "", $code = 0, $status = true)
    {
        $json_data = [
            "status" => $status ? true : false,
            "code" => intval($code),
            "msg" => strval($msg),
            "data" => $data,
        ];
        header('Content-Type: application/json');
        exit(json_encode($json_data));
    }
}
