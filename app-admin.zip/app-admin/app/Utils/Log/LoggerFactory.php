<?php namespace App\Utils\Log;


class LoggerFactory {

    private static $loggers = [];

    public static function getLogger($name = "") {
        if (!isset(self::$loggers[$name])) {
            $logger = new Logger($name);
            self::$loggers[$name] = $logger;
        }
        return self::$loggers[$name];
    }

    /**
     * @return array
     */
    public static function getLoggers() {
        return self::$loggers;
    }
}
