<?php namespace App\Utils\Log;

/**
 * Class LoggerConfig
 *
 * ===========================================
 * 示例：
 *
 *  LoggerConfig::registerShutdown();// 注册关闭函数，非常重要
 *  LoggerConfig::setLogDir("/tmp/log");// 设置根路径
 *  $map = [
 *      'App\Http\Controllers' => 'test.case'
 *  ];
 *  LoggerConfig::setNameMap($map);// 设置类对应的日志名称，不设置则为默认common.log
 *
 * ===========================================
 */
class LoggerConfig {

    private static $nameMap = [];
    private static $logDir = "";
    private static $isRegisterShutdown = false;

    /**
     * @return array
     */
    public static function getNameMap() {
        return self::$nameMap;
    }

    /**
     * @param array $nameMap
     */
    public static function setNameMap($nameMap) {
        self::$nameMap = $nameMap;
    }

    /**
     * @return string
     */
    public static function getLogDir() {
        return self::$logDir;
    }

    /**
     * @param string $logDir
     */
    public static function setLogDir($logDir) {
        self::$logDir = $logDir;
    }

    public static function registerShutdown() {
        if (self::$isRegisterShutdown === true) {
            return;
        }
        register_shutdown_function(array(__CLASS__, 'shutdown'));
        self::$isRegisterShutdown = true;
        return;
    }

    /**
     * 关闭时执行函数
     */
    public static function shutdown() {
        // 后台执行
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }

        $loggers = LoggerFactory::getLoggers();
        if (empty($loggers)) {
            return;
        }
        foreach ($loggers as $logger) {
            $logger->flushBuffer();
            $logger->setBufferSize(1);
        }
    }
}
