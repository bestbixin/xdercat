<?php namespace App\Utils\Log;

/**
 * Class Logger
 */
class Logger {

    private $buffer = [];
    private $bufferSize = 0;
    private $fileName = "";
    private $pid = 0;
    private $name = "";
    private $logDir = "";

    function __construct($name) {
        $this->name = $name;
        $this->buildfileName($name);
        $this->buildPid();
        $this->buildLogDir();
    }

    public function debug($message) {
        $this->log("DEBUG " . $message);
    }

    public function info($message) {
        $this->log("INFO " . $message);
    }

    public function warn($message) {
        $this->log("WARN " . $message);
    }

    public function error($message) {
        $this->log("ERROR " . $message);
    }

    public function flushBuffer() {
        $this->write();
    }

    /**
     * @param int $bufferSize
     */
    public function setBufferSize($bufferSize) {
        $this->bufferSize = $bufferSize;
    }

    private function log($message) {
        $date = date("Y-m-d H:i:s.") . $this->getDecimalTime();
        $message = $date . " [" . $this->pid . "_" . $this->name . "] " . $message . "\n";
        $this->pushBuffer($message);
    }

    private function getDecimalTime() {
        $microtime = microtime(true);
        $result = explode('.', $microtime);
        return substr(end($result), 0, 3);
    }

    private function pushBuffer($message) {
        array_push($this->buffer, $message);
        if ($this->bufferSize > 0 && count($this->buffer) % $this->bufferSize === 0) {
            $this->flushBuffer();
        }
    }

    private function buildFileName($name) {
        $day = date("Y-m-d");
        $nameMap = $this->getNameMap();
        $separateName = explode('\\', $name);
        if (empty($separateName)) {
            $this->fileName = "common.log" . $day;
            return;
        }
        for ($n = count($separateName) ; $n > 0 ; $n--) {
            $tmpName = implode("\\", $separateName);
            if (isset($nameMap[$tmpName])) {
                $this->fileName = $nameMap[$tmpName] . ".log" . $day;
                return;
            }
            array_pop($separateName);
        }
        $this->fileName = "common.log" . $day;
        return;
    }

    private function buildPid() {
        $this->pid = getmypid();
    }

    private function buildLogDir() {
        $logDir = LoggerConfig::getLogDir();
        if (empty($logDir)) {
            throw new \Exception("No config directory for log");
        }
        if(!file_exists($logDir)) {
            if (!mkdir($logDir, 0777, true)) {
                throw new \Exception("No permission to make directory");
            }
            try {
                chmod($logDir, 0777);
            } catch (\Exception $e) {
            }
        }
        $this->logDir = $logDir;
    }

    private function getNameMap() {
        return LoggerConfig::getNameMap();
    }

    private function write() {
        if (empty($this->buffer)) {
            return;
        }
        $file = $this->logDir . DIRECTORY_SEPARATOR . $this->fileName;
        $fp = fopen($file, 'a');
        if ($fp === false) {
            throw new \Exception("No permission to open file:" . $file);
        }
        $message = "";
        foreach ($this->buffer as $key => $buffer) {
            $message .= $buffer;
            unset($this->buffer[$key]);
        }
        fwrite($fp, $message);
        fclose($fp);
        try {
            chmod($file, 0777);
        } catch (\Exception $e) {
        }
    }
}
