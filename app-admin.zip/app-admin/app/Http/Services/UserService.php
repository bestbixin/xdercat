<?php namespace App\Http\Services;

use App\Http\Models\AdminUserModel;
use Illuminate\Support\Facades\Session;

/**
 * Created by IntelliJ IDEA.
 * User: bibom
 * Date: 9/7/17
 * Time: 5:21 PM
 */
class UserService {

    private static $user;

    /**
     * @param $user_name
     * @param $password
     * @return bool
     */
    public function login($user_name, $password) {
        if (empty($user_name)) {
            return false;
        }
        $admin_user = AdminUserModel::where(
            [
                'user_name' => $user_name,
                'password' => md5($password)
            ]
        )->first(
            [
                'admin_id',
                'user_name',
                'admin_name',
                'roles',
            ]
        );
        if (!is_object($admin_user)) {
            return false;
        }
        Session::set('admin_user', $admin_user->toArray());
        Session::save();
        return true;
    }

    public function updatePassword($admin_user, $password) {
        if (empty($admin_user)) {
            return false;
        }
        AdminUserModel::where(
            [
                'admin_id' => $admin_user['admin_id'],
            ]
        )->update(
            [
                'password' => md5($password),
            ]
        );
        return true;
    }

    public function logout() {
        Session::clear();
        Session::save();
    }

    public static function getUser() {
        if (isset(self::$user)) {
            return self::$user;
        }
        $user = Session::get('admin_user');
        self::$user = [];
        if (!empty($user)) {
            self::$user = $user;
        }
        return self::$user;
    }

    /**
     * set admin name by admin id
     * @return object
     */
    static public function setAdminInfo(&$data) {
        if (empty($data)) {
            return;
        }
        $admin_ids = [];
        foreach ($data as $value) {
            $admin_ids[] = $value['admin_id'];
        }
        $result = AdminUserModel::whereIn('admin_id', $admin_ids)->get(['admin_id', 'admin_name'])->toArray();
        $admins = [];
        if (!empty($result)) {
            foreach ($result as $admin) {
                $admins[$admin['admin_id']] = $admin;
            }
        }
        foreach ($data as $key => $value) {
            $data[$key]['admin_name'] = isset($admins[$value['admin_id']]) ? $admins[$value['admin_id']]['admin_name'] : "";
        }
    }

    static public function getAdminIdsByAdminName($admin_name) {
        if (empty($admin_name)) {
            return [];
        }
        $admins = AdminUserModel::where('admin_name', 'like', $admin_name . '%')->get(['admin_id']);
        $admins = $admins->toArray();
        if (empty($admins)) {
            return [];
        }
        $admin_ids = [];
        foreach ($admins as $admin) {
            $admin_ids[$admin['admin_id']] = $admin['admin_id'];
        }
        return array_values($admin_ids);
    }
}
