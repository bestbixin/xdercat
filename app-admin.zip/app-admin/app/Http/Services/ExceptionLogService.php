<?php namespace App\Http\Services;

use App\Utils\Log\LoggerFactory;

class ExceptionLogService {
    /**
     * 异常处理器
     */
    public static function exceptionHandler(\Exception $e) {
        $logger = LoggerFactory::getLogger("Exception");
        $logger->error(sprintf('%s', $e));
    }
}
