<?php namespace App\Http\Controllers;

use App\Http\Services\UserService;
use Illuminate\Http\Request;

/**
 * Created by IntelliJ IDEA.
 * User: bibom
 * Date: 9/7/17
 * Time: 10:46 AM
 */
class UserController extends BaseController {

    private $user_service;

    public function __construct() {
        parent::__construct(__CLASS__);
        $this->user_service = new UserService();
    }

    public function index() {
        if (!empty($this->admin_user)) {
            return redirect('/');
        }
        return view('user.index', []);
    }

    public function login(Request $request) {
        try {
            $format = [
                "user_name" => [
                    "type" => "string",
                    "empty" => "请输入用户名"
                ],
                "password" => [
                    "type" => "string",
                    "md5empty" => "请输入密码"
                ],
            ];
            $data = $request->all();
            $error_msg = filterData($data, $format);
            if (!empty($error_msg)) {
                return errorJson($error_msg);
            }
            $result = $this->user_service->login($data['user_name'], $data['password']);
            if ($result) {
                return successJson([], "登录成功");
            }
            return errorJson("登录失败");
        } catch (\Exception $e) {
            $this->exceptionHandler($e);
            return errorJson("登录失败", 400);
        }
    }

    public function logout() {
        $this->user_service->logout();
        return redirect('/sso/login');
    }

    public function updatePasswordView() {
        if (empty($this->admin_user)) {
            return redirect('/sso/login');
        }
        return view('user.update_password', []);
    }

    public function updatePassword(Request $request) {
        try {
            if (empty($this->admin_user)) {
                return errorJson("请先登录额~");
            }
            $format = [
                "password" => [
                    "type" => "string",
                    "md5empty" => "请输入新密码"
                ],
            ];
            $data = $request->all();
            $error_msg = filterData($data, $format);
            if (!empty($error_msg)) {
                return errorJson($error_msg);
            }
            $result = $this->user_service->updatePassword($this->admin_user, $data['password']);
            if ($result) {
                return successJson([], "修改成功");
            }
            return errorJson("修改失败");
        } catch (\Exception $e) {
            $this->exceptionHandler($e);
            return errorJson("修改失败", 400);
        }
    }
}