<?php namespace App\Http\Controllers;

use App\Http\Services\UserService;
use App\Utils\Log\LoggerFactory;
use App\Http\Services\ExceptionLogService;

class BaseController extends Controller {

    protected $logger;
    protected $admin_user;

    public function __construct($subClassName) {
        $this->logger = LoggerFactory::getLogger($subClassName);
        $this->admin_user = UserService::getUser();
    }

    /**
     * 异常处理器
     */
    public function exceptionHandler(\Exception $e) {
        ExceptionLogService::exceptionHandler($e);
    }
}