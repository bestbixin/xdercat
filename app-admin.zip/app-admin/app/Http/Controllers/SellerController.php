<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * Created by IntelliJ IDEA.
 * User: bibom
 * Date: 9/7/17
 * Time: 10:46 AM
 */
class SellerController extends BaseController {

    public function __construct() {
        parent::__construct(__CLASS__);
    }

    public function index() {
        return view('seller.index', []);
    }
}