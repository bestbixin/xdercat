<?php

namespace App\Http\Middleware;

use App\Http\Services\UserService;
use App\Utils\Log\LoggerFactory;
use Closure;

class Authenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        // 获取用户信息
        $admin_user = UserService::getUser();
        if(empty($admin_user)) {
            if($request->ajax()) {// ajax 请求返回json格式提示信息
                return errorJson("请先登录额~");
            } else {
                return redirect('/sso/login');
            }
        }

        // 记录用户日志
        $logger = LoggerFactory::getLogger("AdminLog");
        $logger->info(sprintf('admin_id:%s user_name:%s admin_name:%s url:%s method:%s ip:%s request data:%s', $admin_user['admin_id'], $admin_user['user_name'], $admin_user['admin_name'], $request->fullUrl(), $request->method(), $request->ip(), json_encode($request->all(), JSON_UNESCAPED_UNICODE)));

        return $next($request);
    }
}
