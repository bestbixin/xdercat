<?php namespace App\Http\Middleware;

use App\Utils\Log\LoggerConfig;
use App\Utils\Log\LoggerFactory;
use Closure;

class Config {

    /**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next) {
        $this->configLog();
        $this->configSqlLog();
        $this->configMenu();
        return $next($request);
	}

    /**
     * 配置Log
     *
     * */
    private function configLog() {
        LoggerConfig::setLogDir(env("LOG_DIR", "/tmp"));
        LoggerConfig::setNameMap(config("logger"));
        LoggerConfig::registerShutdown();
    }

    /**
     * 配置SQL Log
     *
     * */
    private function configSqlLog() {
        \Event::listen('illuminate.query', function($query, $bindings, $time) {
            $logger = LoggerFactory::getLogger("SQL");
            $query = trim($query);
            $type = substr($query, 0, 6);
            if (strtoupper($type) !== 'SELECT') {// 记录非select语句
                $logger->warn($query . '; runtime:' . $time . 'ms; bindings:' . json_encode($bindings));
            }
            if ($time > 500) {// 记录大于500ms日志
                $logger->warn($query . '; runtime:' . $time . 'ms; bindings:' . json_encode($bindings));
            }
        });
    }

    private function configMenu() {
        $path = \Request::path();
        $path = array_filter(explode('/', $path));
        // ********项目做大请把菜单移至数据库，用缓存*********
        $menu = [
            [
                'level' => 1,
                'name' => '运营管理',
                'code' => 'operation',
                'sub_menu' => [
                    [
                        'level' => 2,
                        'name' => '商家列表',
                        'code' => 'seller',
                    ],
                    [
                        'level' => 2,
                        'name' => '会员列表',
                        'code' => 'member',
                    ],
                ],
            ],
        ];
        if (empty($path)) {
            array_push($path, current($menu)['code']);
        }
        foreach ($menu as $key => $first_menu) {
            $menu[$key]['is_active'] = 0;
            $first_code = current($path);
            if ($first_menu['code'] != $first_code) {
                continue;
            }
            $menu[$key]['is_active'] = 1;
            if (empty($first_menu['sub_menu'])) {
                continue;
            }
            next($path);
            $sub_code = current($path);
            if (empty($sub_code)) {
                $sub_code = current($first_menu['sub_menu'])['code'];
            }
            foreach ($first_menu['sub_menu'] as $index => $sub_menu) {
                $menu[$key]['sub_menu'][$index]['is_active'] = 0;
                if ($sub_code != $sub_menu['code']) {
                    continue;
                }
                $menu[$key]['sub_menu'][$index]['is_active'] = 1;
            }
        }
        \Config::set('app_menu', $menu);
    }
}
