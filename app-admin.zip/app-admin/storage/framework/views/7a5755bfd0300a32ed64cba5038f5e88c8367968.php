<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('common.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="my-content">
    <div class="content-header">商家管理</div>
    <ul class="breadcrumb">
        <li><a href="<?php echo request('/operation'); ?>">运营管理</a> <span class="divider">/</span>
        </li>
        <li class="active">商家列表</li>
    </ul>
    <div class="breadcrumb">

    </div>
</div>
<script type="text/javascript" src="<?php echo vasset('/js/laypage/laypage.js'); ?>"></script>
<script type="text/javascript" src="<?php echo vasset('/js/layer/extend/layer.ext.js'); ?>"></script>
<script type="text/javascript">
</script>
<?php echo $__env->make('common.bottom', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
